window.onload = function() {
    customScroll();
}

function customScroll() {
    let $animateWrapper = document.getElementById("animate-wrapper");
    let $animationSection = document.getElementById("animation-section");
    let animationSectionOffset = offset($animationSection);
    let heightBody = $animateWrapper.offsetHeight;
    document.body.style.height = heightBody + 1000 + "px";

    let state = false;
    let positionScroll = 0;

    window.addEventListener('scroll', function () {
        $animateWrapper.setAttribute("style",`transform: translateY(-${pageYOffset}px)`);

        console.log(pageYOffset)
        // console.log(animationSectionOffset.top)

        if(pageYOffset > animationSectionOffset.top) {
            if(state === false) {
                state = true;
                positionScroll = pageYOffset;
            }



            $animateWrapper.setAttribute("style",`transform: translateY(-${animationSectionOffset.top}px)`);

            console.log("sk - " + positionScroll)
            if(animationSectionOffset.top >= animationSectionOffset.top + 80) {

            }
        }

    });


    function offset(el) {
        let rect = el.getBoundingClientRect(),
            scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
            scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        return {top: rect.top + scrollTop, left: rect.left + scrollLeft}
    }
    // console.log(divOffset.left, divOffset.top); Example
}


function sliderMaterials() {
    let $itemTab = document.querySelectorAll(".tab-materials__list");
    let $itemSlide = document.querySelectorAll(".tab-materials__slider-item");
    let tabActiveClass = "tab-materials__list--active";
    let itemSlideActiveClass = "tab-materials__slider-item--active";

    this.hideSlide = () => {
        hideSlide();
    }
    this.showSlide = (index) => {
        showSlide(index)
    }
    this.activeSlide = () => {
        isActiveSlide()
    }

    function isActiveSlide() {
        $itemTab.forEach((element)=>{
            if(element.classList.contains(tabActiveClass)) {
                return console.log(element)
            }
        })
        $itemSlide.forEach((element)=>{
            if(element.classList.contains(itemSlideActiveClass)) {
                return console.log(element)
            }
        })
    }

    function hideSlide() {
        $itemTab.forEach((element)=>{
            element.classList.remove(tabActiveClass)
        })
        $itemSlide.forEach((element)=>{
            element.classList.remove(itemSlideActiveClass)
        })
    }

    function showSlide(index) {
        $itemTab[index].classList.add(tabActiveClass)
        $itemSlide[index].classList.add(itemSlideActiveClass)
    }
}

window.callSlider = new sliderMaterials();

callSlider.hideSlide();
callSlider.showSlide(1);
callSlider.activeSlide();































